# Jubayda AI

A Bangla-first personal AI assistant for Android. Created by **Aminul Islam Sabbir**.

> **Status: architecture + working scaffold**, not a finished production app.
> The spec behind this project (15 screens, phone control, voice, permission
> center, memory, full backend) is a multi-week build. What's here is a real,
> buildable Android Studio project with the correct architecture, navigation
> wired end-to-end across all 15 screens, and working implementations of the
> highest-value pieces: **Chat** (Compose UI + ViewModel + Repository + Room +
> Retrofit), the **Permission Center**, **Settings**, **Home**, and the
> **device-action executor** (open app / open settings panel) that phone
> control features are built on. Everything else is a wired, navigable stub
> with a `TODO` marking exactly what to fill in — see "What's implemented"
> below.

## Architecture

```
MVVM + Clean-ish layering
UI (Compose)  →  ViewModel  →  Repository  →  { Retrofit API, Room DB, DataStore }
```

- **DI**: Hilt (`di/NetworkModule.kt`, `di/StorageModule.kt`)
- **Networking**: Retrofit + OkHttp + kotlinx.serialization, talking to
  **your own backend** — never directly to an LLM provider from the phone.
- **Local storage**: Room (chat history, memory facts), DataStore
  (non-sensitive settings), EncryptedSharedPreferences via
  `androidx.security.crypto` (auth token).
- **Navigation**: Jetpack Navigation Compose, one `NavHost` in
  `ui/navigation/JubaydaNavGraph.kt` covering all 15 screens from the spec.

## Folder structure

```
app/src/main/java/com/aminul/jubayda/
  ui/screens/<feature>/     — one folder per screen (Compose UI + ViewModel)
  ui/theme/                 — black + gold dark theme, typography
  ui/navigation/            — NavGraph + Routes
  data/local/db/            — Room entities + DAOs
  data/local/datastore/     — settings + secure token storage
  data/remote/api/          — Retrofit interface
  data/remote/dto/          — wire-format request/response models
  data/repository/          — single source of truth per feature
  domain/model/             — UI-facing models
  di/                       — Hilt modules
  util/                     — DeviceActionExecutor (app launching, settings panels)
```

## What's implemented vs. stubbed

| Feature | Status |
|---|---|
| Navigation across all 15 screens | ✅ wired |
| Chat (UI, ViewModel, Room persistence, Retrofit call) | ✅ working |
| Permission Center (status per permission, reason shown, Settings deep-link) | ✅ working UI; runtime request dialog has a `TODO` (needs `ActivityResultContracts.RequestPermission` wired from `MainActivity`) |
| Settings (language, memory toggle via DataStore) | ✅ working |
| Home quick actions | ✅ working |
| Device action executor (open app / uninstall dialog / settings panels) | ✅ working, official Intents only |
| Onboarding, Auth, Voice Assistant, App Manager, AI Tools, Chat History, Memory, Privacy Center, About, Permission Setup | 🚧 stub screens, `TODO` comments mark what to build |
| Backend | ❌ not included — this repo is the Android client only |

## Backend

The Android app never talks to an LLM provider directly, so a small backend
is required. It is **not** part of this repo — build it separately (e.g.
FastAPI or Node/Express) with:

- `POST /v1/chat` matching `ChatRequest`/`ChatResponse` in
  `data/remote/dto/ChatDto.kt`
- The LLM provider's API key stored **only** in that backend's own
  environment variables (see `docs/backend.env.example`)
- Your own auth (issue a short-lived bearer token the app stores via
  `SecureTokenStore`)

## Setup

1. Install Android Studio (Koala or newer), JDK 17.
2. `cp local.properties.example local.properties` and fill in your `sdk.dir`
   and `API_BASE_URL` (your backend's URL, not an LLM provider's).
3. Open the project root in Android Studio and let Gradle sync.

## Build

```bash
./gradlew assembleDebug      # debug APK
./gradlew assembleRelease    # release APK (needs signing config, below)
./gradlew bundleRelease      # release AAB for Play Store
```

## Release signing

Add a signing config before shipping — do **not** commit the keystore:

```kotlin
// app/build.gradle.kts, inside android { }
signingConfigs {
    create("release") {
        storeFile = file(System.getenv("JUBAYDA_KEYSTORE_PATH") ?: "release.keystore")
        storePassword = System.getenv("JUBAYDA_KEYSTORE_PASSWORD")
        keyAlias = System.getenv("JUBAYDA_KEY_ALIAS")
        keyPassword = System.getenv("JUBAYDA_KEY_PASSWORD")
    }
}
buildTypes {
    release { signingConfig = signingConfigs.getByName("release") }
}
```

Then `./gradlew bundleRelease` produces `app/build/outputs/bundle/release/app-release.aab`
for upload to Play Console.

## Security notes (already applied)

- `cleartextTrafficPermitted="false"` app-wide — HTTPS only.
- Auth token stored in `EncryptedSharedPreferences` (Android Keystore-backed), never in
  plain DataStore or logs.
- No API key of any kind is compiled into the Android client.
- Every permission in `AndroidManifest.xml` maps to a real, user-visible feature and
  a plain-language explanation in the Permission Center — none are requested silently.
- `DeviceActionExecutor` only calls public `Intent`/`Settings` APIs — no reflection,
  no accessibility-service abuse, no permission bypass.

## Next steps, roughly in priority order

1. Wire the real runtime permission request flow (`ActivityResultContracts`) in `MainActivity`
   and call it from `PermissionCenterScreen`'s "Grant" button.
2. Implement `AppManagerScreen` using `PackageManager.getInstalledApplications` (needs the
   `QUERY_ALL_PACKAGES` permission already declared).
3. Build the backend's `/v1/chat` endpoint.
4. Implement `AuthScreen` (guest mode is simplest to start: skip straight to Home, issue no
   token, restrict Chat to a rate-limited anonymous backend route).
5. Voice: `SpeechRecognizer` for STT, `TextToSpeech` for TTS — both official Android APIs,
   no third-party SDK needed for a first version.
6. Memory screen: list/edit/delete rows from `MemoryDao`, gated by the Settings memory toggle.
