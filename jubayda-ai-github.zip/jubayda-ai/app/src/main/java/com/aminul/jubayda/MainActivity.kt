package com.aminul.jubayda

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.aminul.jubayda.ui.navigation.JubaydaNavGraph
import com.aminul.jubayda.ui.theme.JubaydaTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JubaydaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    JubaydaNavGraph()
                }
            }
        }
    }
}
