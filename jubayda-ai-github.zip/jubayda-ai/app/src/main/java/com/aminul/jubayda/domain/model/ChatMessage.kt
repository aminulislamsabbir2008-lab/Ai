package com.aminul.jubayda.domain.model

data class ChatMessage(
    val text: String,
    val isFromUser: Boolean,
    val timestamp: Long
)
