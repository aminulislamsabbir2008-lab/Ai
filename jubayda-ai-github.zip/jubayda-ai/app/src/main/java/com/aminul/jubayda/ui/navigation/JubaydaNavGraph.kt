package com.aminul.jubayda.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aminul.jubayda.ui.screens.about.AboutScreen
import com.aminul.jubayda.ui.screens.apps.AppManagerScreen
import com.aminul.jubayda.ui.screens.auth.AuthScreen
import com.aminul.jubayda.ui.screens.chat.ChatScreen
import com.aminul.jubayda.ui.screens.history.ChatHistoryScreen
import com.aminul.jubayda.ui.screens.home.HomeScreen
import com.aminul.jubayda.ui.screens.memory.MemoryScreen
import com.aminul.jubayda.ui.screens.onboarding.OnboardingScreen
import com.aminul.jubayda.ui.screens.permission.PermissionSetupScreen
import com.aminul.jubayda.ui.screens.permissioncenter.PermissionCenterScreen
import com.aminul.jubayda.ui.screens.privacy.PrivacyCenterScreen
import com.aminul.jubayda.ui.screens.settings.SettingsScreen
import com.aminul.jubayda.ui.screens.splash.SplashScreen
import com.aminul.jubayda.ui.screens.tools.AiToolsScreen
import com.aminul.jubayda.ui.screens.voice.VoiceAssistantScreen

/**
 * Every screen from the spec (section 12) is wired here.
 * Screens are currently functional skeletons — see each file's TODOs for
 * where real logic (API calls, permission checks, app launching) plugs in.
 */
object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val PERMISSION_SETUP = "permission_setup"
    const val AUTH = "auth"
    const val HOME = "home"
    const val CHAT = "chat"
    const val VOICE = "voice"
    const val APP_MANAGER = "app_manager"
    const val PERMISSION_CENTER = "permission_center"
    const val AI_TOOLS = "ai_tools"
    const val CHAT_HISTORY = "chat_history"
    const val MEMORY = "memory"
    const val SETTINGS = "settings"
    const val PRIVACY_CENTER = "privacy_center"
    const val ABOUT = "about"
}

@Composable
fun JubaydaNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) { SplashScreen(navController) }
        composable(Routes.ONBOARDING) { OnboardingScreen(navController) }
        composable(Routes.PERMISSION_SETUP) { PermissionSetupScreen(navController) }
        composable(Routes.AUTH) { AuthScreen(navController) }
        composable(Routes.HOME) { HomeScreen(navController) }
        composable(Routes.CHAT) { ChatScreen(navController) }
        composable(Routes.VOICE) { VoiceAssistantScreen(navController) }
        composable(Routes.APP_MANAGER) { AppManagerScreen(navController) }
        composable(Routes.PERMISSION_CENTER) { PermissionCenterScreen(navController) }
        composable(Routes.AI_TOOLS) { AiToolsScreen(navController) }
        composable(Routes.CHAT_HISTORY) { ChatHistoryScreen(navController) }
        composable(Routes.MEMORY) { MemoryScreen(navController) }
        composable(Routes.SETTINGS) { SettingsScreen(navController) }
        composable(Routes.PRIVACY_CENTER) { PrivacyCenterScreen(navController) }
        composable(Routes.ABOUT) { AboutScreen(navController) }
    }
}
