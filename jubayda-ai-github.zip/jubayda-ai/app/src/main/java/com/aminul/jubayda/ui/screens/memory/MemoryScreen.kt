package com.aminul.jubayda.ui.screens.memory

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController

/**
 * TODO: implement Memory per spec. This is a wired, navigable stub so the
 * app builds and the full navigation flow (section 12) is in place end to end.
 */
@Composable
fun MemoryScreen(navController: NavHostController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Memory") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Memory — coming soon")
        }
    }
}
