package com.aminul.jubayda.data.local.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val text: String,
    val isFromUser: Boolean,
    val timestamp: Long
)

/**
 * "Memory" facts (section 9) are stored separately from raw chat history so the
 * user can view/edit/delete them individually from the Memory screen, per spec.
 */
@Entity(tableName = "memory_facts")
data class MemoryFactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val createdAt: Long
)

@Dao
interface ChatDao {
    @Insert
    suspend fun insertMessage(message: MessageEntity)

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun observeConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT DISTINCT conversationId FROM messages ORDER BY timestamp DESC")
    fun observeConversationIds(): Flow<List<String>>

    @Query("DELETE FROM messages")
    suspend fun clearAllHistory()

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun clearConversation(conversationId: String)
}

@Dao
interface MemoryDao {
    @Insert
    suspend fun insertFact(fact: MemoryFactEntity)

    @Query("SELECT * FROM memory_facts ORDER BY createdAt DESC")
    fun observeFacts(): Flow<List<MemoryFactEntity>>

    @Query("DELETE FROM memory_facts WHERE id = :id")
    suspend fun deleteFact(id: Long)

    @Query("DELETE FROM memory_facts")
    suspend fun clearAllMemory()
}

@Database(
    entities = [MessageEntity::class, MemoryFactEntity::class],
    version = 1,
    exportSchema = true
)
abstract class JubaydaDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
}
