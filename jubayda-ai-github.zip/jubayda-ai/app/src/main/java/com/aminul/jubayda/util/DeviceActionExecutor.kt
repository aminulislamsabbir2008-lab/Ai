package com.aminul.jubayda.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Every "phone control" action Jubayda can take (spec section 3), implemented
 * ONLY via public Android Intents/APIs. Nothing here reads private data,
 * bypasses a permission dialog, or acts without the user's own tap having
 * triggered the request.
 *
 * Returns a Result so the caller (ChatViewModel) can tell the user honestly
 * whether the action actually happened — Jubayda must never claim success it
 * didn't have (spec section 14).
 */
sealed class ActionResult {
    data object Success : ActionResult()
    data class Failed(val reason: String) : ActionResult()
}

class DeviceActionExecutor(private val context: Context) {

    fun openApp(packageName: String): ActionResult {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            context.startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult.Success
        } else {
            ActionResult.Failed("App not installed or not launchable: $packageName")
        }
    }

    fun openAppInfo(packageName: String): ActionResult = launch(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    )

    fun requestUninstall(packageName: String): ActionResult = launch(
        Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
    )

    fun openSettingsPanel(panel: SettingsPanel): ActionResult = launch(Intent(panel.action))

    private fun launch(intent: Intent): ActionResult = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success
    } catch (e: Exception) {
        ActionResult.Failed(e.message ?: "Unknown error")
    }
}

/** Maps spec section 3's "open X settings" list to real Settings actions. */
enum class SettingsPanel(val action: String) {
    GENERAL(Settings.ACTION_SETTINGS),
    WIFI(Settings.ACTION_WIFI_SETTINGS),
    BLUETOOTH(Settings.ACTION_BLUETOOTH_SETTINGS),
    DISPLAY(Settings.ACTION_DISPLAY_SETTINGS),
    SOUND(Settings.ACTION_SOUND_SETTINGS),
    BATTERY(Settings.ACTION_BATTERY_SAVER_SETTINGS),
    STORAGE(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
    NOTIFICATIONS(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
}
