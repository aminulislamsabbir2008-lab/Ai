package com.aminul.jubayda.data.remote.dto

import kotlinx.serialization.Serializable

/**
 * Wire format for Jubayda's backend (not the raw LLM provider API — the phone
 * NEVER talks to an LLM provider directly with a secret key; it talks to our
 * own backend, which holds the key server-side).
 */
@Serializable
data class ChatRequest(
    val message: String,
    val conversationId: String? = null,
    val language: String = "bn" // bn | en | ar
)

@Serializable
data class ChatResponse(
    val reply: String,
    val conversationId: String,
    val action: ActionSuggestion? = null
)

/**
 * When Jubayda's reply implies a device action ("open Chrome"), the backend
 * returns a structured suggestion instead of Jubayda pretending to act on its
 * own — the client executes it via an official Android API and confirms back.
 */
@Serializable
data class ActionSuggestion(
    val type: String,       // e.g. "OPEN_APP", "OPEN_SETTINGS_PANEL"
    val target: String,     // e.g. package name or settings panel id
    val requiresPermission: String? = null
)
