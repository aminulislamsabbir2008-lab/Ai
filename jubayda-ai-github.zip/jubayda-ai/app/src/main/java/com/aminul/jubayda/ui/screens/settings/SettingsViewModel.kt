package com.aminul.jubayda.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aminul.jubayda.data.local.datastore.SettingsDataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(val language: String = "bn", val memoryEnabled: Boolean = true)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsDataStore
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState())
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            settings.language.collect { _state.value = _state.value.copy(language = it) }
        }
        viewModelScope.launch {
            settings.memoryEnabled.collect { _state.value = _state.value.copy(memoryEnabled = it) }
        }
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { settings.setMemoryEnabled(enabled) }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch { settings.setLanguage(lang) }
    }
}
