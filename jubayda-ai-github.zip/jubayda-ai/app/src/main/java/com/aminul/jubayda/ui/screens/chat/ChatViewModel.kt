package com.aminul.jubayda.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aminul.jubayda.data.repository.ChatRepository
import com.aminul.jubayda.domain.model.ChatMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val conversationId: String = UUID.randomUUID().toString(),
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val isSending: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: ChatRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeConversation(_state.value.conversationId).collect { messages ->
                _state.value = _state.value.copy(messages = messages)
            }
        }
    }

    fun onInputChange(text: String) {
        _state.value = _state.value.copy(input = text)
    }

    fun sendMessage() {
        val text = _state.value.input.trim()
        if (text.isEmpty() || _state.value.isSending) return

        _state.value = _state.value.copy(input = "", isSending = true, error = null)
        viewModelScope.launch {
            try {
                repository.sendMessage(_state.value.conversationId, text)
            } catch (e: Exception) {
                // Never pretend the message sent successfully if it didn't (spec section 14/16).
                _state.value = _state.value.copy(error = "পাঠানো যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।")
            } finally {
                _state.value = _state.value.copy(isSending = false)
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch { repository.clearHistory(_state.value.conversationId) }
    }
}
