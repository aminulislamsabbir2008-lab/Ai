package com.aminul.jubayda.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "jubayda_settings")

/**
 * Plain, non-sensitive preferences (section 8: name, language, theme, etc).
 * Anything sensitive (tokens) goes through SecureTokenStore instead, never here.
 */
@Singleton
class SettingsDataStore @Inject constructor(private val context: Context) {

    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val LANGUAGE = stringPreferencesKey("language") // bn | en | ar
        val RESPONSE_STYLE = stringPreferencesKey("response_style")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val ONBOARDING_COMPLETE = booleanPreferencesKey("onboarding_complete")
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
    }

    val language: Flow<String> = context.dataStore.data.map { it[Keys.LANGUAGE] ?: "bn" }
    val memoryEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.MEMORY_ENABLED] ?: true }
    val onboardingComplete: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDING_COMPLETE] ?: false }

    suspend fun setLanguage(lang: String) = context.dataStore.edit { it[Keys.LANGUAGE] = lang }
    suspend fun setMemoryEnabled(enabled: Boolean) = context.dataStore.edit { it[Keys.MEMORY_ENABLED] = enabled }
    suspend fun setOnboardingComplete(done: Boolean) = context.dataStore.edit { it[Keys.ONBOARDING_COMPLETE] = done }
    suspend fun setUserName(name: String) = context.dataStore.edit { it[Keys.USER_NAME] = name }
}
