package com.aminul.jubayda

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Jubayda AI — application entry point.
 * Hilt builds the dependency graph (network, database, datastore, repositories)
 * defined under di/.
 */
@HiltAndroidApp
class JubaydaApp : Application()
