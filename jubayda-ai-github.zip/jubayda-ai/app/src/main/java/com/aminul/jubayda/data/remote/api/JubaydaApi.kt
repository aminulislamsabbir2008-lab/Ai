package com.aminul.jubayda.data.remote.api

import com.aminul.jubayda.data.remote.dto.ChatRequest
import com.aminul.jubayda.data.remote.dto.ChatResponse
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * All calls go through HTTPS to our own backend (see build.gradle BuildConfig.API_BASE_URL).
 * The backend — not this app — holds the LLM provider's API key.
 * Auth is via a short-lived bearer token attached in AuthInterceptor (di/NetworkModule.kt).
 */
interface JubaydaApi {
    @POST("v1/chat")
    suspend fun sendMessage(@Body request: ChatRequest): ChatResponse
}
