package com.aminul.jubayda.di

import android.content.Context
import androidx.room.Room
import com.aminul.jubayda.data.local.datastore.SettingsDataStore
import com.aminul.jubayda.data.local.db.ChatDao
import com.aminul.jubayda.data.local.db.JubaydaDatabase
import com.aminul.jubayda.data.local.db.MemoryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object StorageModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): JubaydaDatabase =
        Room.databaseBuilder(context, JubaydaDatabase::class.java, "jubayda.db")
            // Chat text is local-only and not treated as highly sensitive by default;
            // enable SQLCipher here if the user's threat model requires encryption at rest.
            .build()

    @Provides
    fun provideChatDao(db: JubaydaDatabase): ChatDao = db.chatDao()

    @Provides
    fun provideMemoryDao(db: JubaydaDatabase): MemoryDao = db.memoryDao()

    @Provides
    @Singleton
    fun provideSettingsDataStore(@ApplicationContext context: Context): SettingsDataStore =
        SettingsDataStore(context)
}
