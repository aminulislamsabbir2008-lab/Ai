package com.aminul.jubayda.data.repository

import com.aminul.jubayda.data.local.datastore.SettingsDataStore
import com.aminul.jubayda.data.local.db.ChatDao
import com.aminul.jubayda.data.local.db.MessageEntity
import com.aminul.jubayda.data.remote.api.JubaydaApi
import com.aminul.jubayda.data.remote.dto.ChatRequest
import com.aminul.jubayda.domain.model.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val api: JubaydaApi,
    private val chatDao: ChatDao,
    private val settings: SettingsDataStore
) {
    fun observeConversation(conversationId: String): Flow<List<ChatMessage>> =
        chatDao.observeConversation(conversationId).map { list ->
            list.map { ChatMessage(it.text, it.isFromUser, it.timestamp) }
        }

    /**
     * Sends the user's message to the backend and persists both sides locally.
     * Memory-writing (section 9) only happens if the user has memory enabled.
     */
    suspend fun sendMessage(conversationId: String, text: String): ChatMessage {
        val lang = settings.language.first()
        chatDao.insertMessage(MessageEntity(conversationId = conversationId, text = text, isFromUser = true, timestamp = System.currentTimeMillis()))

        val response = api.sendMessage(ChatRequest(message = text, conversationId = conversationId, language = lang))

        chatDao.insertMessage(
            MessageEntity(conversationId = response.conversationId, text = response.reply, isFromUser = false, timestamp = System.currentTimeMillis())
        )
        return ChatMessage(response.reply, isFromUser = false, timestamp = System.currentTimeMillis())
    }

    suspend fun clearHistory(conversationId: String? = null) {
        if (conversationId == null) chatDao.clearAllHistory() else chatDao.clearConversation(conversationId)
    }
}
