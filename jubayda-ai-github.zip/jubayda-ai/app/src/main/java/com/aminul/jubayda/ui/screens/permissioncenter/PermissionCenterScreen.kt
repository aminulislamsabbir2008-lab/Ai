package com.aminul.jubayda.ui.screens.permissioncenter

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController

private data class PermissionInfo(
    val label: String,
    val manifestPermission: String,
    val reason: String
)

// Section 5: every permission Jubayda might ever request, with a plain-language reason.
// Only the ones actually needed for a feature the user turns on should be requested at runtime —
// this screen just shows current status + a Grant button that opens the official system dialog flow.
private val trackedPermissions = listOf(
    PermissionInfo("Microphone", Manifest.permission.RECORD_AUDIO, "ভয়েস দিয়ে Jubayda-কে কমান্ড দেওয়ার জন্য প্রয়োজন।"),
    PermissionInfo("Camera", Manifest.permission.CAMERA, "ছবি বিশ্লেষণ (Analyze Image) ফিচারের জন্য প্রয়োজন।"),
    PermissionInfo("Notifications", Manifest.permission.POST_NOTIFICATIONS, "Jubayda-র উত্তর ও রিমাইন্ডার জানানোর জন্য।"),
    PermissionInfo("Contacts", Manifest.permission.READ_CONTACTS, "\"অমুককে কল করো\" জাতীয় কমান্ডের জন্য (ঐচ্ছিক)।"),
    PermissionInfo("Calendar", Manifest.permission.READ_CALENDAR, "সময়সূচি সম্পর্কিত প্রশ্নের উত্তর দিতে (ঐচ্ছিক)।")
)

@Composable
fun PermissionCenterScreen(navController: NavHostController) {
    val context = LocalContext.current

    Scaffold(topBar = { TopAppBar(title = { Text("Permission Center") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(trackedPermissions) { perm ->
                val granted = ContextCompat.checkSelfPermission(context, perm.manifestPermission) ==
                    PackageManager.PERMISSION_GRANTED

                Card(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(perm.label, style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                        Text(perm.reason, style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
                        Text(if (granted) "স্ট্যাটাস: অনুমোদিত ✅" else "স্ট্যাটাস: অনুমোদিত নয়")

                        Row(modifier = Modifier.padding(top = 8.dp)) {
                            if (!granted) {
                                // Real runtime request is dispatched from an Activity via
                                // ActivityResultContracts.RequestPermission — wired in MainActivity
                                // and triggered from here through a callback (omitted for brevity).
                                Button(onClick = { /* TODO: trigger system permission dialog */ }) {
                                    Text("Grant")
                                }
                            }
                            Button(
                                onClick = {
                                    val intent = Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.padding(start = 8.dp)
                            ) { Text("Settings") }
                        }
                    }
                }
            }
        }
    }
}
