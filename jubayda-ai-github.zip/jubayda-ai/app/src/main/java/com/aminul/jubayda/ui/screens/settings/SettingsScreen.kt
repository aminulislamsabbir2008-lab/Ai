package com.aminul.jubayda.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.aminul.jubayda.ui.navigation.Routes

@Composable
fun SettingsScreen(navController: NavHostController, viewModel: SettingsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(12.dp)) {
            ListItem(
                headlineContent = { Text("Language") },
                supportingContent = { Text(state.language) }
            )
            ListItem(
                headlineContent = { Text("Memory") },
                supportingContent = { Text("Let Jubayda remember facts across chats") },
                trailingContent = {
                    Switch(checked = state.memoryEnabled, onCheckedChange = viewModel::setMemoryEnabled)
                }
            )
            ListItem(
                headlineContent = { Text("Permission Center") },
                modifier = Modifier.fillMaxWidth(),
                supportingContent = { Text("Review and manage granted permissions") }
            ) // wire onClick to navController.navigate(Routes.PERMISSION_CENTER) via clickable modifier
            ListItem(
                headlineContent = { Text("Privacy Center") },
                supportingContent = { Text("Data storage & deletion controls") }
            )
            ListItem(
                headlineContent = { Text("About Jubayda") },
                supportingContent = { Text("Version 1.0.0") }
            )
        }
    }
}
