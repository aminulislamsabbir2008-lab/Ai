package com.aminul.jubayda.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aminul.jubayda.ui.navigation.Routes

private data class QuickAction(val label: String, val route: String)

private val quickActions = listOf(
    QuickAction("Open App", Routes.APP_MANAGER),
    QuickAction("Voice Chat", Routes.VOICE),
    QuickAction("Web Search", Routes.AI_TOOLS),
    QuickAction("Analyze Image", Routes.AI_TOOLS),
    QuickAction("Analyze PDF", Routes.AI_TOOLS),
    QuickAction("Phone Settings", Routes.PERMISSION_CENTER)
)

@Composable
fun HomeScreen(navController: NavHostController) {
    Scaffold { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Hello, I'm Jubayda 👋", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Your Smart Personal AI Assistant",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 20.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(quickActions) { action ->
                    Button(
                        onClick = { navController.navigate(action.route) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(action.label) }
                }
            }

            androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 24.dp))
            Button(onClick = { navController.navigate(Routes.CHAT) }, modifier = Modifier.fillMaxWidth()) {
                Text("চ্যাট শুরু করুন")
            }
        }
    }
}
