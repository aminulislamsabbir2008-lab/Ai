package com.aminul.jubayda.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Jubayda brand palette: black + gold, glassmorphism-friendly surfaces
val JubaydaBlack = Color(0xFF0B0B0D)
val JubaydaSurface = Color(0xFF17171B)
val JubaydaSurfaceGlass = Color(0x33FFFFFF) // overlay for glass cards
val JubaydaGold = Color(0xFFD4AF37)
val JubaydaGoldMuted = Color(0xFF9C8329)
val JubaydaTextPrimary = Color(0xFFF5F5F0)
val JubaydaTextSecondary = Color(0xFFA9A9AE)
val JubaydaError = Color(0xFFCF6679)

private val JubaydaDarkScheme = darkColorScheme(
    primary = JubaydaGold,
    onPrimary = Color.Black,
    secondary = JubaydaGoldMuted,
    background = JubaydaBlack,
    surface = JubaydaSurface,
    onBackground = JubaydaTextPrimary,
    onSurface = JubaydaTextPrimary,
    error = JubaydaError
)

/**
 * Jubayda currently ships dark-mode-first per spec (black + gold).
 * isSystemInDarkTheme() is read for future light-theme support toggled in Settings.
 */
@Composable
fun JubaydaTheme(content: @Composable () -> Unit) {
    val darkTheme = isSystemInDarkTheme() || true // forced dark until light theme is implemented
    MaterialTheme(
        colorScheme = JubaydaDarkScheme,
        typography = JubaydaTypography,
        content = content
    )
}
